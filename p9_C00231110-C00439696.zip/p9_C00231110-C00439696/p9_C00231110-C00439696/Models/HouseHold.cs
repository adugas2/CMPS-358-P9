namespace p9_C00231110_C00439696.Models;

public class HouseHold
{ 
        public int Id { get; set; }
        public string Item { get; set; }
        public string Location { get; set; }
        public string Value { get; set; }
}